// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Attribute.java

package com.isnowfox.io.serialize.tool.model;


// Referenced classes of package com.isnowfox.io.serialize.tool.model:
//			Attribute, AttributeType

static class Attribute$1 {

	static final int $SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[];

	static  {
		$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType = new int[AttributeType.values().length];
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.BOOLEAN.ordinal()] = 1;
		}
		catch (NoSuchFieldError nosuchfielderror) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.FLOAT.ordinal()] = 2;
		}
		catch (NoSuchFieldError nosuchfielderror1) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.DOUBLE.ordinal()] = 3;
		}
		catch (NoSuchFieldError nosuchfielderror2) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.OTHER.ordinal()] = 4;
		}
		catch (NoSuchFieldError nosuchfielderror3) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.INT.ordinal()] = 5;
		}
		catch (NoSuchFieldError nosuchfielderror4) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.LONG.ordinal()] = 6;
		}
		catch (NoSuchFieldError nosuchfielderror5) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.STRING.ordinal()] = 7;
		}
		catch (NoSuchFieldError nosuchfielderror6) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.BYTES.ordinal()] = 8;
		}
		catch (NoSuchFieldError nosuchfielderror7) { }
		try {
			$SwitchMap$com$isnowfox$io$serialize$tool$model$AttributeType[AttributeType.BYTE_BUF.ordinal()] = 9;
		}
		catch (NoSuchFieldError nosuchfielderror8) { }
	}
}
