// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   LogProxy.java

package com.isnowfox.io.serialize.tool;


public interface LogProxy {

	public transient abstract void info(String s, Object aobj[]);
}
