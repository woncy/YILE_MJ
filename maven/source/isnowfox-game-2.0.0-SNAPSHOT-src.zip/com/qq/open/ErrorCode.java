// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ErrorCode.java

package com.qq.open;


public class ErrorCode {

	private static final long serialVersionUID = 0xe8b15d9dea67eef6L;
	public static final int PARAMETER_EMPTY = 1801;
	public static final int PARAMETER_INVALID = 1802;
	public static final int RESPONSE_DATA_INVALID = 1803;
	public static final int MAKE_SIGNATURE_ERROR = 1804;
	public static final int NETWORK_ERROR = 1900;

	public ErrorCode() {
	}
}
