// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   BoundsObject.java

package com.isnowfox.core.geom;


// Referenced classes of package com.isnowfox.core.geom:
//			Rectangle

public interface BoundsObject {

	public abstract Rectangle getBounds();
}
