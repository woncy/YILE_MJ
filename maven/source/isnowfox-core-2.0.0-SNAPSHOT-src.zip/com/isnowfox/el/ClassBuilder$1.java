// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   ClassBuilder.java

package com.isnowfox.el;


// Referenced classes of package com.isnowfox.el:
//			ClassBuilder, KeyInfo

static class ClassBuilder$1 {

	static final int $SwitchMap$com$isnowfox$el$KeyInfo$Type[];

	static  {
		$SwitchMap$com$isnowfox$el$KeyInfo$Type = new int[lues().length];
		try {
			$SwitchMap$com$isnowfox$el$KeyInfo$Type[ELD.dinal()] = 1;
		}
		catch (NoSuchFieldError nosuchfielderror) { }
		try {
			$SwitchMap$com$isnowfox$el$KeyInfo$Type[OPERTY.dinal()] = 2;
		}
		catch (NoSuchFieldError nosuchfielderror1) { }
		try {
			$SwitchMap$com$isnowfox$el$KeyInfo$Type[THOD.dinal()] = 3;
		}
		catch (NoSuchFieldError nosuchfielderror2) { }
	}
}
