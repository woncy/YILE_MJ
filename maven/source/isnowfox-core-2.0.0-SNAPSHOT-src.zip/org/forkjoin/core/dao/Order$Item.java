// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Order.java

package org.forkjoin.core.dao;


// Referenced classes of package org.forkjoin.core.dao:
//			Order

static class Order$Item {

	String name;
	boolean desc;

	Order$Item(String name, boolean desc) {
		this.name = name;
		this.desc = desc;
	}
}
