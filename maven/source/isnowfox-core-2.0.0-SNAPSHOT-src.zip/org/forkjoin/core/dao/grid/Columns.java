// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   Columns.java

package org.forkjoin.core.dao.grid;

import java.util.ArrayList;

public class Columns extends ArrayList {

	private static final long serialVersionUID = 0xd0f0e0311c698436L;

	public Columns() {
	}
}
