// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   StaticFileHandler.java

package com.isnowfox.web.impl.staticfile;

import com.isnowfox.web.Response;

public class StaticFileHandler {

	public StaticFileHandler() {
	}

	public final boolean disposeStaticFile(String path, Response resp) throws Exception {
		return false;
	}
}
