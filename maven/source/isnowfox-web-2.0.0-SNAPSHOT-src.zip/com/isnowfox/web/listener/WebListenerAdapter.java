// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) braces fieldsfirst ansi nonlb space 
// Source File Name:   WebListenerAdapter.java

package com.isnowfox.web.listener;


// Referenced classes of package com.isnowfox.web.listener:
//			WebListener, WebContextEvent, WebResponseEvent, WebRequestEvent

public class WebListenerAdapter
	implements WebListener {

	public WebListenerAdapter() {
	}

	public void contextInitialized(WebContextEvent webcontextevent) {
	}

	public void contextDestroyed(WebContextEvent webcontextevent) {
	}

	public void response(WebResponseEvent webresponseevent) {
	}

	public void requestHandlerStart(WebRequestEvent webrequestevent) {
	}

	public void requestHandlerEnd(WebRequestEvent webrequestevent) {
	}
}
